function fnTest(){
    document.write("자바스크립트 환영!")
    alert("자바 스크립트 환영!!");
}